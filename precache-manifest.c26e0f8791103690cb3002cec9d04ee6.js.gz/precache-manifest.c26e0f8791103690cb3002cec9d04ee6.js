self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0778be7a8c90b9f9249b6e7214dad007",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "e697fa7493aec209d193",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "34b3bb56464947e67a71",
    "url": "/react-pokedex/static/css/main.02fda62e.chunk.css"
  },
  {
    "revision": "e697fa7493aec209d193",
    "url": "/react-pokedex/static/js/2.6009f394.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.6009f394.chunk.js.LICENSE"
  },
  {
    "revision": "34b3bb56464947e67a71",
    "url": "/react-pokedex/static/js/main.fcb7f8c1.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);