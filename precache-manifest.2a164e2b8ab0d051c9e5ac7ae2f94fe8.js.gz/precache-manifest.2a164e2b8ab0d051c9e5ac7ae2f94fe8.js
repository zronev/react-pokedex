self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "3b3334b04a65d598d3eca09450661bbf",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "3780e58064ff38260ed0",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "a276ec8f54c9fac51f33",
    "url": "/react-pokedex/static/css/main.854d272b.chunk.css"
  },
  {
    "revision": "3780e58064ff38260ed0",
    "url": "/react-pokedex/static/js/2.61c5df02.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/react-pokedex/static/js/2.61c5df02.chunk.js.LICENSE"
  },
  {
    "revision": "a276ec8f54c9fac51f33",
    "url": "/react-pokedex/static/js/main.b12bd172.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);