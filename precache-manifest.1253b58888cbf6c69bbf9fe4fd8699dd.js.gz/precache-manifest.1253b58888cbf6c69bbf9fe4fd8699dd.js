self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cf1aa0e8b39df51e6165f42eb5440ced",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "067fc86b86a3f51aae9d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "23bad872594d93817635",
    "url": "/react-pokedex/static/css/main.8cfb2b83.chunk.css"
  },
  {
    "revision": "067fc86b86a3f51aae9d",
    "url": "/react-pokedex/static/js/2.bbf6f428.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.bbf6f428.chunk.js.LICENSE"
  },
  {
    "revision": "23bad872594d93817635",
    "url": "/react-pokedex/static/js/main.7ce9554a.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);