self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e43fd69d802762c93822ed7f22237039",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "77e8853fa003a81da5ab",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "366edde7c90c2ab28a44",
    "url": "/react-pokedex/static/css/main.6e0919d9.chunk.css"
  },
  {
    "revision": "77e8853fa003a81da5ab",
    "url": "/react-pokedex/static/js/2.c81d4bd2.chunk.js"
  },
  {
    "revision": "86afaa925e0f432774bf95b19b6933fb",
    "url": "/react-pokedex/static/js/2.c81d4bd2.chunk.js.LICENSE"
  },
  {
    "revision": "366edde7c90c2ab28a44",
    "url": "/react-pokedex/static/js/main.ff5f3c15.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);