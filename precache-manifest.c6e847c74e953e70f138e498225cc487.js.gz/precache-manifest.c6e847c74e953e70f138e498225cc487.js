self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "743392070da9180c927a8287615fdded",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "623c848d102ca5c2147b",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "72fa94491c5a59502ab7",
    "url": "/react-pokedex/static/css/main.8cfb2b83.chunk.css"
  },
  {
    "revision": "623c848d102ca5c2147b",
    "url": "/react-pokedex/static/js/2.82f0e258.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.82f0e258.chunk.js.LICENSE"
  },
  {
    "revision": "72fa94491c5a59502ab7",
    "url": "/react-pokedex/static/js/main.6c89fddd.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);