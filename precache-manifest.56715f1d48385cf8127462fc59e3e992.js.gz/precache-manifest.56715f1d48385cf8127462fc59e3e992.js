self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "866d70f2ea9b67a64abf4c87a9b050aa",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "781e8342fa6f99d2355b",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "43d194901e016b5af4dd",
    "url": "/react-pokedex/static/css/main.bc4c116d.chunk.css"
  },
  {
    "revision": "781e8342fa6f99d2355b",
    "url": "/react-pokedex/static/js/2.8ed1494b.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.8ed1494b.chunk.js.LICENSE"
  },
  {
    "revision": "43d194901e016b5af4dd",
    "url": "/react-pokedex/static/js/main.71a8e603.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);