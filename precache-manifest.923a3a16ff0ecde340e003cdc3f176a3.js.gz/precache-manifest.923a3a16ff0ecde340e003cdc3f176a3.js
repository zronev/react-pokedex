self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "93d2948c0ce56f6b8a50aff9d14652a6",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "773e55f8922df17fca5c",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "d602000477b3b6242f86",
    "url": "/react-pokedex/static/css/main.5af048cf.chunk.css"
  },
  {
    "revision": "773e55f8922df17fca5c",
    "url": "/react-pokedex/static/js/2.d7ed31b7.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/react-pokedex/static/js/2.d7ed31b7.chunk.js.LICENSE"
  },
  {
    "revision": "d602000477b3b6242f86",
    "url": "/react-pokedex/static/js/main.c3942b05.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);