self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1a6d2a579d6ff965cb681b5e16c35d18",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "463160e3c341f1adb02d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "923ace922df573552b19",
    "url": "/react-pokedex/static/css/main.992f6fe2.chunk.css"
  },
  {
    "revision": "463160e3c341f1adb02d",
    "url": "/react-pokedex/static/js/2.e244c38a.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.e244c38a.chunk.js.LICENSE"
  },
  {
    "revision": "923ace922df573552b19",
    "url": "/react-pokedex/static/js/main.ae90554b.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);