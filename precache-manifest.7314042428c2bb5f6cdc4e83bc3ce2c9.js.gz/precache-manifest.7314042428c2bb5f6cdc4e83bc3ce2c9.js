self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9aba2f43884a69ef23fd8553fdbb19e0",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "8c40f39d79fa55dc9e6e",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "cf0516a11ab51281b232",
    "url": "/react-pokedex/static/css/main.20f4fa64.chunk.css"
  },
  {
    "revision": "8c40f39d79fa55dc9e6e",
    "url": "/react-pokedex/static/js/2.3a2a56cf.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/react-pokedex/static/js/2.3a2a56cf.chunk.js.LICENSE"
  },
  {
    "revision": "cf0516a11ab51281b232",
    "url": "/react-pokedex/static/js/main.4d04b868.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);