self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "67989865c53a98e0b28faceefe9c0a96",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "a6f8c8f47bf0ad6f6a0d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "d122d7ce22900c6000b7",
    "url": "/react-pokedex/static/css/main.f86cf648.chunk.css"
  },
  {
    "revision": "a6f8c8f47bf0ad6f6a0d",
    "url": "/react-pokedex/static/js/2.8d9d56a4.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.8d9d56a4.chunk.js.LICENSE"
  },
  {
    "revision": "d122d7ce22900c6000b7",
    "url": "/react-pokedex/static/js/main.e95ae67c.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);