self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ed908711c0afdaf1a76c6256382049e7",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "a6f8c8f47bf0ad6f6a0d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "261973db14b6ad03ccc8",
    "url": "/react-pokedex/static/css/main.ff65e1e6.chunk.css"
  },
  {
    "revision": "a6f8c8f47bf0ad6f6a0d",
    "url": "/react-pokedex/static/js/2.8d9d56a4.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.8d9d56a4.chunk.js.LICENSE"
  },
  {
    "revision": "261973db14b6ad03ccc8",
    "url": "/react-pokedex/static/js/main.3fc29a0d.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);