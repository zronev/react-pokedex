self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8bbab651a4d20289ebed40b5dae7546a",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "9d82cea2be72652a253e",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "553a332486ce39f1ca27",
    "url": "/react-pokedex/static/css/main.0da7b2cf.chunk.css"
  },
  {
    "revision": "9d82cea2be72652a253e",
    "url": "/react-pokedex/static/js/2.a0f44304.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.a0f44304.chunk.js.LICENSE"
  },
  {
    "revision": "553a332486ce39f1ca27",
    "url": "/react-pokedex/static/js/main.5e97dca1.chunk.js"
  },
  {
    "revision": "6ee779561b2429713e6e",
    "url": "/react-pokedex/static/js/runtime-main.97740bb2.js"
  }
]);