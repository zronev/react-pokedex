self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6a91f3942fcb317290cb3115ee32130a",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "e697fa7493aec209d193",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "118e45689947b0da4bf8",
    "url": "/react-pokedex/static/css/main.778ec2e7.chunk.css"
  },
  {
    "revision": "e697fa7493aec209d193",
    "url": "/react-pokedex/static/js/2.6009f394.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.6009f394.chunk.js.LICENSE"
  },
  {
    "revision": "118e45689947b0da4bf8",
    "url": "/react-pokedex/static/js/main.5bd2d3f0.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);