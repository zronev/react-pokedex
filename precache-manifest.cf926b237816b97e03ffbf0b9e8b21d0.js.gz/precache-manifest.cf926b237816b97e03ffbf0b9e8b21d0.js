self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8b22b3f7b24c002a6e61bdcb2dda50c1",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "833410c2d99285a92730",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "4c5608118a6c934f4b9b",
    "url": "/react-pokedex/static/css/main.483aeea4.chunk.css"
  },
  {
    "revision": "833410c2d99285a92730",
    "url": "/react-pokedex/static/js/2.00d4329b.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.00d4329b.chunk.js.LICENSE"
  },
  {
    "revision": "4c5608118a6c934f4b9b",
    "url": "/react-pokedex/static/js/main.371b1a4f.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);