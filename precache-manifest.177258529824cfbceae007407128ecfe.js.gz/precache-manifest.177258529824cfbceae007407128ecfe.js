self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2bc1831e6907697261fbd81f8a074a98",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "77e8853fa003a81da5ab",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "62888b79fdbec5a07a7b",
    "url": "/react-pokedex/static/css/main.4060543c.chunk.css"
  },
  {
    "revision": "77e8853fa003a81da5ab",
    "url": "/react-pokedex/static/js/2.c81d4bd2.chunk.js"
  },
  {
    "revision": "86afaa925e0f432774bf95b19b6933fb",
    "url": "/react-pokedex/static/js/2.c81d4bd2.chunk.js.LICENSE"
  },
  {
    "revision": "62888b79fdbec5a07a7b",
    "url": "/react-pokedex/static/js/main.43365c36.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);