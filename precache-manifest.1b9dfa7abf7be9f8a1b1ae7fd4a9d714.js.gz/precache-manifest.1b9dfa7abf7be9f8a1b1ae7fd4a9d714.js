self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2e9b71fccb4c1599c56a0b90a83b405a",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "067fc86b86a3f51aae9d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "79d5d429da687b459f6b",
    "url": "/react-pokedex/static/css/main.8cfb2b83.chunk.css"
  },
  {
    "revision": "067fc86b86a3f51aae9d",
    "url": "/react-pokedex/static/js/2.bbf6f428.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.bbf6f428.chunk.js.LICENSE"
  },
  {
    "revision": "79d5d429da687b459f6b",
    "url": "/react-pokedex/static/js/main.271748c6.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);