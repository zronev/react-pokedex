self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2da8b0828b388fc8d0ee97f17e222517",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "463160e3c341f1adb02d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "b44775c1fadb8ff18115",
    "url": "/react-pokedex/static/css/main.992f6fe2.chunk.css"
  },
  {
    "revision": "463160e3c341f1adb02d",
    "url": "/react-pokedex/static/js/2.e244c38a.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.e244c38a.chunk.js.LICENSE"
  },
  {
    "revision": "b44775c1fadb8ff18115",
    "url": "/react-pokedex/static/js/main.3647a808.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);