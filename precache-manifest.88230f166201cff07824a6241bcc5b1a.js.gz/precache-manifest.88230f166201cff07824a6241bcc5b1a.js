self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c07aa30588a75d5497eb5def451f869d",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "1152d693cd7d5f11468c",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "f6aead1a9bf7fbe8c8af",
    "url": "/react-pokedex/static/css/main.a141a7fa.chunk.css"
  },
  {
    "revision": "1152d693cd7d5f11468c",
    "url": "/react-pokedex/static/js/2.8ec0139c.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.8ec0139c.chunk.js.LICENSE"
  },
  {
    "revision": "f6aead1a9bf7fbe8c8af",
    "url": "/react-pokedex/static/js/main.6f8d5cd2.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);