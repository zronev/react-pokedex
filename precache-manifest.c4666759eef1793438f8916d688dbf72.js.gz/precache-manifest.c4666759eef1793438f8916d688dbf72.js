self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e0343c3f0197924f65e15472c4b955cc",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "9d82cea2be72652a253e",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "9a92321f3aaf4bd59f1b",
    "url": "/react-pokedex/static/css/main.3eb8e2e3.chunk.css"
  },
  {
    "revision": "9d82cea2be72652a253e",
    "url": "/react-pokedex/static/js/2.a0f44304.chunk.js"
  },
  {
    "revision": "44bb13c376a360a26522c8368cf779a1",
    "url": "/react-pokedex/static/js/2.a0f44304.chunk.js.LICENSE"
  },
  {
    "revision": "9a92321f3aaf4bd59f1b",
    "url": "/react-pokedex/static/js/main.f18cdb7f.chunk.js"
  },
  {
    "revision": "6ee779561b2429713e6e",
    "url": "/react-pokedex/static/js/runtime-main.97740bb2.js"
  }
]);