self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "cf0a322dc0fe35d148222354e15f6cd1",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "c28d78db5872d99edc7d",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "1546b38d183690d18f55",
    "url": "/react-pokedex/static/css/main.5af048cf.chunk.css"
  },
  {
    "revision": "c28d78db5872d99edc7d",
    "url": "/react-pokedex/static/js/2.c2e84ccf.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/react-pokedex/static/js/2.c2e84ccf.chunk.js.LICENSE"
  },
  {
    "revision": "1546b38d183690d18f55",
    "url": "/react-pokedex/static/js/main.5dcb18d6.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);