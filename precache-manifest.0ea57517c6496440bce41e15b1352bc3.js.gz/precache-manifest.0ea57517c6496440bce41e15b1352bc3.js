self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f1a2818514a1f6a9b98f24cbfab592e2",
    "url": "/react-pokedex/index.html"
  },
  {
    "revision": "3780e58064ff38260ed0",
    "url": "/react-pokedex/static/css/2.764ccc25.chunk.css"
  },
  {
    "revision": "345352eab5a9fab1759a",
    "url": "/react-pokedex/static/css/main.d57924d6.chunk.css"
  },
  {
    "revision": "3780e58064ff38260ed0",
    "url": "/react-pokedex/static/js/2.61c5df02.chunk.js"
  },
  {
    "revision": "e928fe768baa9832b5bc57eae021f30c",
    "url": "/react-pokedex/static/js/2.61c5df02.chunk.js.LICENSE"
  },
  {
    "revision": "345352eab5a9fab1759a",
    "url": "/react-pokedex/static/js/main.015b57a2.chunk.js"
  },
  {
    "revision": "ebecc74468765ea72f07",
    "url": "/react-pokedex/static/js/runtime-main.f71a6969.js"
  }
]);